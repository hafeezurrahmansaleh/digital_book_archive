from django.shortcuts import render

# Create your views here.
from django.http import Http404
from rest_framework import status
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.decorators import (
    api_view,
    permission_classes,
    renderer_classes
)
from rest_framework.permissions import (
    IsAuthenticated, AllowAny, IsAdminUser, IsAuthenticatedOrReadOnly
)
from .permissions import IsOwnerOrReadOnly
from .models import *
from .serializers import *
from .owners import SectionOwner


# Create your views here.


class PublisherList(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = PublisherProfileSerializer
    queryset = PublisherProfile.objects.all()


# all Publisher related profile
class PublisherProfileDetail(generics.RetrieveUpdateAPIView):
    """
    endpoint for viewing logged Publisher
    user id should be pass as parameter
    """
    permission_classes = (IsOwnerOrReadOnly,)
    serializer_class = PublisherProfileUpdateSerializer
    queryset = PublisherProfile.objects.all()
    lookup_field = 'user'


# all Restaurant related profiles


# all customer profile related class
class CustomerProfileCreate(generics.CreateAPIView):
    """
    endpoint for creating customer profile
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = CustomerProfileSerializer
    queryset = CustomerProfile.objects.all()

    def perform_create(self, serializer):
        user = self.request.user
        querydata = UserRole.objects.filter(user=user, role_name='publisher')
        customerdata = CustomerProfile.objects.filter(user=user)
        # if user is superuser
        if user.is_superuser:
            raise ValidationError(
                'Superuser can not create a customer profile'
            )
        elif querydata.exists():
            raise ValidationError(
                'Publisher can not create a customer profile')
        elif customerdata.exists():
            raise ValidationError('Customer profile already exists')
        else:
            serializer.save(user=user)


class CustomerProfileDetail(generics.RetrieveUpdateAPIView):
    """
    endpoint for retrieve update and delete customer profile
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = CustomerProfileSerializer
    queryset = CustomerProfile.objects.all()

    def get_object(self):
        user = self.request.user
        if user.is_superuser or user.is_staff:
            raise ValidationError('This section is for customer only')
        return SectionOwner().is_customer(user)


class ViewUserProfile(generics.RetrieveAPIView):
    """
    endpoint for viewing user(customer,publisher profile)
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = User.objects.all()


"""
view user data
"""


class UserDataDetail(generics.RetrieveAPIView):
    """
    endpoint for retrieving all user data data from user table
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = User.objects.all()
