from django.db import models
from django.contrib.auth.models import User
from user_profile.models import *

# Create your models here.


# Create your models here.
class EmailVerificationCode(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="email_verification"
    )
    code = models.CharField(max_length=128)
    is_verified = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-id']


class ForgetPasswordCode(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )
    code = models.CharField(max_length=200)
    is_verified = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-id']

