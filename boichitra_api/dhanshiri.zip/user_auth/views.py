from django.shortcuts import render

# Create your views here.

from django.http import Http404
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.decorators import (
    api_view,
    permission_classes,
    renderer_classes
)
from rest_framework.permissions import (
    IsAuthenticated,
    AllowAny,
    IsAdminUser,
    IsAuthenticatedOrReadOnly
)
from user_profile.models import *
from user_profile.serializers import *
from .serializers import *
# from customer_order.models import FoodOrder
from .models import *
from .serializers import VerifyEmailSerializer
from .verification import Verification
import random,math
import string
import hashlib


# Create your views here.

def randomString(stringLength=10):
    """Generate a random string of fixed length """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))


# function to generate OTP
def generateOTP(otpLength = 4):

    """Generate a random OTP of fixed length """
    digits = "0123456789"
    OTP = ""

    # length of password can be changed
    # by changing value in range
    for i in range(otpLength):
        OTP += digits[math.floor(random.random() * 10)]
    return OTP


class CustomerSignUp(generics.CreateAPIView):
    """
    endpoint for customer sign up
    """
    permission_classes = (AllowAny,)
    serializer_class = CreateCustomerSerializer

    def perform_create(self, serializer):
        email = serializer.validated_data['email']
        number_code = "{}".format(randomString(10))
        code = hashlib.md5(number_code.encode())
        new_code = code.hexdigest()
        otp = generateOTP(4)
        ins = serializer.save(is_active=False,password=otp)
        EmailVerificationCode.objects.create(
            user=ins,
            code=new_code
        )
        Verification().send_email_verification_code(email, new_code)
        print('code sent')


class VerifyEmail(generics.UpdateAPIView):
    """
    endpoint for verify email address
    """
    permission_classes = (AllowAny,)
    serializer_class = VerifyEmailSerializer
    queryset = EmailVerificationCode.objects.all()

    def get_object(self):
        return

    def perform_update(self, serializer):
        email = serializer.validated_data['email']
        code = serializer.validated_data['code']
        try:
            instance = EmailVerificationCode.objects.get(
                user__user__email=email,
                code=code,
                is_verified=False
            )
        except EmailVerificationCode.DoesNotExist:
            raise ValidationError('Code Expired')
        instance.is_verified = True
        instance.save()

        user_instance = User.objects.get(username=instance.user.user.username)
        user_instance.is_active = True
        user_instance.save()


class ChangePassword(APIView):
    """
    end point for changing user password
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = ChangePasswordSerializer

    def get_object(self, queryset=None):
        return self.request.user

    def put(self, request, *arg, **kwargs):
        self.object = self.get_object()
        serializer = ChangePasswordSerializer(data=request.data)

        if serializer.is_valid():
            response = {}
            old_password = serializer.data.get("old_password")
            if not self.object.check_password(old_password):
                return Response({"errors": ["Wrong password"]}, status=status.HTTP_400_BAD_REQUEST)
            self.object.set_password(serializer.data.get('new_password'))
            self.object.save()
            response["success"] = "Password updated successfully"
            return Response(response, status=status.HTTP_204_NO_CONTENT)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CurrentUserDetail(generics.RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user


class SendPasswordResetCode(generics.CreateAPIView):
    """
    end point for sending password reset email
    """
    permission_classes = (AllowAny,)
    serializer_class = SendOTPConSerializer

    def perform_create(self, serializer):
        email = serializer.validated_data['email']
        try:
            instance = User.objects.get(email=email, is_active=True)
        except User.DoesNotExist:
            raise ValidationError('No active account found with this email')
        number_code = "{}".format(randomString(10))
        code = hashlib.md5(number_code.encode())
        new_code = code.hexdigest()

        ForgetPasswordCode.objects.create(
            user=instance,
            code=new_code
        )
        Verification().send_password_reset_email(email, new_code)


class ResetPassword(generics.RetrieveUpdateAPIView):
    """
    endpoint for verifying password code
    """
    permission_classes = (AllowAny,)
    serializer_class = PasswordResetSerializer
    queryset = User.objects.all()
    lookup_fields = ['email', 'code']

    def get_object(self):
        email = self.kwargs.get('email')
        code = self.kwargs.get('code')
        try:
            instance = ForgetPasswordCode.objects.get(
                user__email=email,
                code=code,
                is_verified=False
            )
            instance.is_verified = True
            instance.save()
        except ForgetPasswordCode.DoesNotExist:
            raise ValidationError('Invalid code')

    def perform_update(self, serializer):
        email = self.kwargs.get('email')
        instance = User.objects.get(
            email=email
        )
        instance.set_password(serializer.validated_data['new_password'])
        instance.save()
