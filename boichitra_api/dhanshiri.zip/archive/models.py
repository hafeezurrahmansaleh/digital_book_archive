from django.db import models

# Create your models here.
from user_profile.models import *


class Category(models.Model):
    id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=128)
    description = models.CharField(max_length=128, null=True, blank=True)
    category_image = models.ImageField(
        null=True,
        blank=True,
        upload_to="categories/",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class BookDetails(models.Model):
    id = models.AutoField(primary_key=True)
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE
    )
    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,
        related_name='book_author'
    )
    publisher = models.ForeignKey(
        PublisherProfile,
        on_delete=models.CASCADE,
        related_name='book_publisher'
    )
    isbn = models.CharField(
        max_length=50,
        null=True,
        blank=True
    )
    book_name = models.CharField(
        max_length=200,
        null=True,
        blank=True
    )
    book_short_name = models.CharField(max_length=40, null=True, blank=True)
    description = models.CharField(max_length=8000, null=True, blank=True)
    cover_image = models.ImageField(
        null=True,
        blank=True,
        upload_to="cover_image/",
    )
    is_active = models.BooleanField(default=True)
    created_by = models.BigIntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_by = models.BigIntegerField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)


class BookDetailsAssociation(models.Model):
    id = models.AutoField(primary_key=True)
    book_details = models.ForeignKey(
        BookDetails,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    table_id = models.BigIntegerField()
    table_name = models.CharField(max_length=200)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class SubscriptionType(models.Model):
    id = models.AutoField(primary_key=True)
    type = models.CharField(max_length=True)
    limit = models.ImageField()
    cost = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )
    description = models.CharField(
        max_length=1000,
        null=True,
        blank=True
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Subscription(models.Model):
    STATUS_CHOICES = {
        'Active': 'Active',
        'Pending': 'Pending',
        'Suspended': 'Suspended',
        'Expired': 'Expired'
    }
    id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(
        CustomerProfile,
        on_delete=models.SET_NULL,
        null=True
    )
    subscription_type = models.ForeignKey(
        SubscriptionType,
        on_delete=models.SET_NULL,
        null=True
    )
    item = models.ForeignKey(
        BookDetails,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    total_cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True
    )
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(
        choices=STATUS_CHOICES,
        default='Active'
    )
    slug = models.SlugField(max_length=200)

    class Meta:
        ordering = ('-created_at',)

    def __str__(self):
        return self.customer.full_name + self.subscription_type.type
